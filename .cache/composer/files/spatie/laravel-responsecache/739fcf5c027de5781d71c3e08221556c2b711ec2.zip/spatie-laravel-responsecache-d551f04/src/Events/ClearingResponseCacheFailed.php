<?php

namespace Spatie\ResponseCache\Events;

class ClearingResponseCacheFailed
{
}
