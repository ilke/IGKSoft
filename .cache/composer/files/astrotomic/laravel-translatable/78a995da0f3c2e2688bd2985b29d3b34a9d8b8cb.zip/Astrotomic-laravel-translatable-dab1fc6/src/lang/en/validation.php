<?php

declare(strict_types=1);

return [
    'translatableUnique' => 'The :attribute value is already in use.',
    'translatableExist' => 'The :attribute value does not exist.',
];
